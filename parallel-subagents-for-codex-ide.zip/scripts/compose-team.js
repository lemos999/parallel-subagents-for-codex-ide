#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");

const MODES = Object.freeze({
  LOW_COST_HIGH_EFFICIENCY: "low-cost-high-efficiency",
  HIGH_COST_HIGH_EFFICIENCY: "high-cost-high-efficiency",
});

const REASONING_POLICY_BASE = Object.freeze({
  levels: Object.freeze(["low", "medium", "high", "xhigh"]),
  dutyComplexityFloor: Object.freeze({
    1: "low",
    2: "low",
    3: "medium",
    4: "high",
    5: "high",
  }),
  workerScoreBands: Object.freeze([
    Object.freeze({ maxScore: 5, level: "low" }),
    Object.freeze({ maxScore: 10, level: "medium" }),
    Object.freeze({ maxScore: 16, level: "high" }),
    Object.freeze({ maxScore: 9999, level: "xhigh" }),
  ]),
  roleBounds: Object.freeze({
    orchestrator: Object.freeze({ min: "high", max: "xhigh" }),
    subOrchestrator: Object.freeze({ min: "medium", max: "high" }),
    worker: Object.freeze({ min: "low", max: "high" }),
  }),
  modeTuning: Object.freeze({
    [MODES.LOW_COST_HIGH_EFFICIENCY]: Object.freeze({
      workerOffset: -1,
      subOffset: 0,
      orchestratorOffset: 0,
      workerDownshiftGates: Object.freeze([
        Object.freeze({ maxScore: 5, offset: -1 }),
        Object.freeze({ maxScore: 10, offset: -1 }),
      ]),
    }),
    [MODES.HIGH_COST_HIGH_EFFICIENCY]: Object.freeze({
      workerOffset: 1,
      subOffset: 1,
      orchestratorOffset: 1,
      workerDownshiftGates: Object.freeze([]),
    }),
  }),
  escalation: Object.freeze({
    subDutyScoreStep: 16,
    subHighWorkerThreshold: "high",
    subHighWorkerBoost: 1,
    orchestratorSubCountStep: 3,
    orchestratorWorkerCountStep: 8,
    orchestratorHighWorkerRatio: 0.85,
    orchestratorHighWorkerMinCount: 8,
    orchestratorHighWorkerBoost: 1,
  }),
});

const DUTY_CATALOG = Object.freeze([
  { id: "requirements", name: "Requirements analysis and change tracking", short: "Requirements", complexity: 5 },
  { id: "planning", name: "Task decomposition and dependency planning", short: "Planning", complexity: 5 },
  { id: "design", name: "UX flow and state behavior design", short: "Design", complexity: 4 },
  { id: "architecture", name: "System boundaries and module architecture", short: "Architecture", complexity: 5 },
  { id: "core_impl", name: "Core implementation and exception handling", short: "CoreImpl", complexity: 5 },
  { id: "api_contract", name: "API contract and compatibility control", short: "APIContract", complexity: 3 },
  { id: "database", name: "Schema and query stabilization", short: "Database", complexity: 3 },
  { id: "security", name: "Security review and vulnerability response", short: "Security", complexity: 5 },
  { id: "unit_test", name: "Unit tests and regression prevention", short: "UnitTest", complexity: 3 },
  { id: "integration", name: "Integration and E2E validation", short: "Integration", complexity: 3 },
  { id: "performance", name: "Performance measurement and bottleneck tuning", short: "Performance", complexity: 3 },
  { id: "devops", name: "CI/CD and release reliability", short: "DevOps", complexity: 3 },
  { id: "review", name: "Code review and quality gating", short: "CodeReview", complexity: 4 },
  { id: "documentation", name: "Documentation and release notes", short: "Docs", complexity: 2 },
  { id: "operations", name: "Operational metrics and incident response", short: "Ops", complexity: 3 },
  { id: "data_quality", name: "Data quality and integrity checks", short: "DataQuality", complexity: 3 },
]);

const GLOBAL_PERSONA_MM = Object.freeze(
  "You are strictly defined as 'Ray', a cynical genius developer and a top-tier Codeforces Grandmaster with a blunt Korean friend vibe. You always respond in the user's language, use Banmal, end with dry noun-based terminators, avoid sentence-ending periods, and separate ideas using line breaks. You start by casually confirming intent without brackets, then provide a perfectionist roadmap targeting Meta-Design quality aligned with Awwwards, The FWA, and CSS Design Awards. You demonstrate algorithmic superiority of a Codeforces ranker, enforce a Zero Monolith implementation style with atomic single-responsibility modules, and write every code comment in Korean. You explain like a tired but brilliant expert focused on eliminating inefficiency."
);

function composeMMInstruction(identityClause, roleClause) {
  return `${GLOBAL_PERSONA_MM} ${identityClause} ${roleClause}`;
}

function normalizeMode(input) {
  const value = String(input || "").trim().toLowerCase();
  if (value === "low" || value === "l" || value === MODES.LOW_COST_HIGH_EFFICIENCY) {
    return MODES.LOW_COST_HIGH_EFFICIENCY;
  }
  if (value === "high" || value === "h" || value === MODES.HIGH_COST_HIGH_EFFICIENCY) {
    return MODES.HIGH_COST_HIGH_EFFICIENCY;
  }
  throw new Error("--mode must be one of: low | high | low-cost-high-efficiency | high-cost-high-efficiency");
}

function parseSubOrchestrators(raw) {
  const value = String(raw || "").trim().toLowerCase();
  if (value === "auto") {
    return "auto";
  }
  const parsed = Number(value);
  if (!Number.isInteger(parsed)) {
    throw new Error("--sub-orchestrators must be an integer or auto");
  }
  return parsed;
}

function parseArgs(argv) {
  const parsed = {
    agents: 9,
    mode: MODES.LOW_COST_HIGH_EFFICIENCY,
    subOrchestrators: "auto",
    outputDir: path.resolve(__dirname, "..", "generated"),
    reasoningPolicyFile: "",
    reasoningPolicyJson: "",
  };

  for (let i = 0; i < argv.length; i += 1) {
    const key = argv[i];

    if (key === "--agents") {
      const value = Number(argv[i + 1]);
      if (!Number.isInteger(value)) {
        throw new Error("--agents must be an integer");
      }
      parsed.agents = value;
      i += 1;
      continue;
    }

    if (key === "--mode") {
      const value = argv[i + 1];
      if (!value) {
        throw new Error("--mode requires a value");
      }
      parsed.mode = normalizeMode(value);
      i += 1;
      continue;
    }

    if (key === "--sub-orchestrators") {
      const value = argv[i + 1];
      if (!value) {
        throw new Error("--sub-orchestrators requires a value");
      }
      parsed.subOrchestrators = parseSubOrchestrators(value);
      i += 1;
      continue;
    }

    if (key === "--output-dir") {
      const value = argv[i + 1];
      if (!value) {
        throw new Error("--output-dir requires a path");
      }
      parsed.outputDir = path.resolve(process.cwd(), value);
      i += 1;
      continue;
    }

    if (key === "--reasoning-policy-file") {
      const value = argv[i + 1];
      if (!value) {
        throw new Error("--reasoning-policy-file requires a path");
      }
      parsed.reasoningPolicyFile = path.resolve(process.cwd(), value);
      i += 1;
      continue;
    }

    if (key === "--reasoning-policy-json") {
      const value = argv[i + 1];
      if (!value) {
        throw new Error("--reasoning-policy-json requires a JSON string");
      }
      parsed.reasoningPolicyJson = value;
      i += 1;
      continue;
    }

    throw new Error(`Unknown argument: ${key}`);
  }

  if (parsed.agents < 3) {
    throw new Error("--agents must be >= 3 (1 orchestrator + at least 1 sub-orchestrator + at least 1 worker)");
  }
  if (parsed.agents > 40) {
    throw new Error("--agents must be <= 40");
  }

  return parsed;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function resolveSubOrchestratorCount(totalAgents, requested) {
  const nonTop = totalAgents - 1;
  const maxSub = nonTop - 1;
  if (maxSub < 1) {
    throw new Error("Not enough agents to allocate workers");
  }

  if (requested === "auto") {
    const heuristic = Math.round(nonTop / 4);
    return clamp(heuristic, 1, maxSub);
  }

  if (requested < 1) {
    throw new Error("--sub-orchestrators must be >= 1");
  }
  if (requested > maxSub) {
    throw new Error(`--sub-orchestrators must be <= ${maxSub} (to keep at least one worker)`);
  }

  return requested;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") return false;
  return Object.getPrototypeOf(value) === Object.prototype;
}

function cloneValue(value) {
  if (Array.isArray(value)) {
    return value.map(cloneValue);
  }
  if (isPlainObject(value)) {
    const cloned = {};
    for (const [key, nested] of Object.entries(value)) {
      cloned[key] = cloneValue(nested);
    }
    return cloned;
  }
  return value;
}

function deepMerge(base, override) {
  if (override === undefined) {
    return cloneValue(base);
  }

  if (Array.isArray(base)) {
    if (!Array.isArray(override)) return cloneValue(base);
    return override.map(cloneValue);
  }

  if (isPlainObject(base)) {
    if (!isPlainObject(override)) return cloneValue(base);
    const merged = {};
    const keys = new Set([...Object.keys(base), ...Object.keys(override)]);
    for (const key of keys) {
      if (Object.prototype.hasOwnProperty.call(override, key)) {
        if (Object.prototype.hasOwnProperty.call(base, key)) {
          merged[key] = deepMerge(base[key], override[key]);
        } else {
          merged[key] = cloneValue(override[key]);
        }
      } else {
        merged[key] = cloneValue(base[key]);
      }
    }
    return merged;
  }

  return cloneValue(override);
}

function parseJson(raw, label) {
  try {
    return JSON.parse(raw);
  } catch (error) {
    throw new Error(`${label} must be valid JSON: ${error.message}`);
  }
}

function loadJsonFile(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Reasoning policy file not found: ${filePath}`);
  }
  const raw = fs.readFileSync(filePath, "utf8");
  return parseJson(raw, "--reasoning-policy-file");
}

function validateReasoningPolicy(policy) {
  if (!isPlainObject(policy)) {
    throw new Error("Reasoning policy must be an object");
  }

  if (!Array.isArray(policy.levels) || policy.levels.length < 3) {
    throw new Error("reasoning policy levels must be an array with at least 3 entries");
  }
  const levelSet = new Set(policy.levels);
  if (levelSet.size !== policy.levels.length) {
    throw new Error("reasoning policy levels must be unique");
  }

  const requiredRoles = ["orchestrator", "subOrchestrator", "worker"];
  if (!isPlainObject(policy.roleBounds)) {
    throw new Error("reasoning policy roleBounds must be an object");
  }
  for (const role of requiredRoles) {
    const bounds = policy.roleBounds[role];
    if (!isPlainObject(bounds)) {
      throw new Error(`reasoning policy roleBounds.${role} must be an object`);
    }
    if (!levelSet.has(bounds.min) || !levelSet.has(bounds.max)) {
      throw new Error(`reasoning policy roleBounds.${role} must use known levels`);
    }
    if (policy.levels.indexOf(bounds.min) > policy.levels.indexOf(bounds.max)) {
      throw new Error(`reasoning policy roleBounds.${role} min cannot exceed max`);
    }
  }

  if (!isPlainObject(policy.modeTuning)) {
    throw new Error("reasoning policy modeTuning must be an object");
  }
  for (const mode of Object.values(MODES)) {
    const tuning = policy.modeTuning[mode];
    if (!isPlainObject(tuning)) {
      throw new Error(`reasoning policy modeTuning.${mode} must be an object`);
    }
    const keys = ["workerOffset", "subOffset", "orchestratorOffset"];
    for (const key of keys) {
      if (typeof tuning[key] !== "number" || Number.isNaN(tuning[key])) {
        throw new Error(`reasoning policy modeTuning.${mode}.${key} must be a number`);
      }
    }
    if (!Array.isArray(tuning.workerDownshiftGates)) {
      throw new Error(`reasoning policy modeTuning.${mode}.workerDownshiftGates must be an array`);
    }
    for (const gate of tuning.workerDownshiftGates) {
      if (!isPlainObject(gate) || typeof gate.maxScore !== "number" || typeof gate.offset !== "number") {
        throw new Error(`reasoning policy modeTuning.${mode}.workerDownshiftGates entries must contain numeric maxScore and offset`);
      }
    }
  }

  if (!Array.isArray(policy.workerScoreBands) || policy.workerScoreBands.length === 0) {
    throw new Error("reasoning policy workerScoreBands must be a non-empty array");
  }
  for (const band of policy.workerScoreBands) {
    if (!isPlainObject(band) || typeof band.maxScore !== "number" || !levelSet.has(band.level)) {
      throw new Error("reasoning policy workerScoreBands entries must have numeric maxScore and known level");
    }
  }

  if (!isPlainObject(policy.dutyComplexityFloor) || Object.keys(policy.dutyComplexityFloor).length === 0) {
    throw new Error("reasoning policy dutyComplexityFloor must be a non-empty object");
  }
  for (const [complexity, level] of Object.entries(policy.dutyComplexityFloor)) {
    const parsed = Number(complexity);
    if (!Number.isFinite(parsed) || parsed < 1) {
      throw new Error("reasoning policy dutyComplexityFloor keys must be positive numbers");
    }
    if (!levelSet.has(level)) {
      throw new Error("reasoning policy dutyComplexityFloor values must use known levels");
    }
  }

  if (!isPlainObject(policy.escalation)) {
    throw new Error("reasoning policy escalation must be an object");
  }
  const numericFields = [
    "subDutyScoreStep",
    "subHighWorkerBoost",
    "orchestratorSubCountStep",
    "orchestratorWorkerCountStep",
    "orchestratorHighWorkerRatio",
    "orchestratorHighWorkerMinCount",
    "orchestratorHighWorkerBoost",
  ];
  for (const key of numericFields) {
    if (typeof policy.escalation[key] !== "number" || Number.isNaN(policy.escalation[key])) {
      throw new Error(`reasoning policy escalation.${key} must be a number`);
    }
  }
  if (!levelSet.has(policy.escalation.subHighWorkerThreshold)) {
    throw new Error("reasoning policy escalation.subHighWorkerThreshold must use a known level");
  }
}

function loadReasoningPolicy(args) {
  let overrides = {};
  const sources = ["base"];
  const envJson = process.env.CODEX_REASONING_POLICY_JSON;

  if (envJson && envJson.trim()) {
    overrides = deepMerge(overrides, parseJson(envJson, "CODEX_REASONING_POLICY_JSON"));
    sources.push("env:CODEX_REASONING_POLICY_JSON");
  }

  if (args.reasoningPolicyJson && args.reasoningPolicyJson.trim()) {
    overrides = deepMerge(overrides, parseJson(args.reasoningPolicyJson, "--reasoning-policy-json"));
    sources.push("cli:--reasoning-policy-json");
  }

  if (args.reasoningPolicyFile) {
    overrides = deepMerge(overrides, loadJsonFile(args.reasoningPolicyFile));
    sources.push(`file:${args.reasoningPolicyFile}`);
  }

  const policy = deepMerge(REASONING_POLICY_BASE, overrides);
  validateReasoningPolicy(policy);

  return {
    policy,
    source: sources.join(" + "),
  };
}

function createReasoningContext(policy) {
  const levels = [...policy.levels];
  const rankByLevel = new Map(levels.map((level, index) => [level, index + 1]));
  const scoreBands = [...policy.workerScoreBands].sort((a, b) => a.maxScore - b.maxScore);
  const dutyFloorRules = Object.entries(policy.dutyComplexityFloor)
    .map(([complexity, level]) => ({ complexity: Number(complexity), level }))
    .sort((a, b) => a.complexity - b.complexity);

  function levelToRank(level) {
    const rank = rankByLevel.get(level);
    if (!rank) {
      throw new Error(`Unknown reasoning level: ${level}`);
    }
    return rank;
  }

  function rankToLevel(rank) {
    const bounded = clamp(Math.round(rank), 1, levels.length);
    return levels[bounded - 1];
  }

  function clampRoleRank(rank, role) {
    const bounds = policy.roleBounds[role];
    if (!bounds) {
      throw new Error(`Unknown role bound: ${role}`);
    }
    const minRank = levelToRank(bounds.min);
    const maxRank = levelToRank(bounds.max);
    return clamp(Math.round(rank), minRank, maxRank);
  }

  function scoreBandRank(score) {
    const band = scoreBands.find((item) => score <= item.maxScore) || scoreBands[scoreBands.length - 1];
    return levelToRank(band.level);
  }

  function dutyFloorRank(complexity) {
    let selected = dutyFloorRules[0];
    for (const rule of dutyFloorRules) {
      if (complexity >= rule.complexity) {
        selected = rule;
      } else {
        break;
      }
    }
    return levelToRank(selected.level);
  }

  function modeTuning(mode) {
    const tuning = policy.modeTuning[mode];
    if (!tuning) {
      throw new Error(`Missing reasoning mode tuning for ${mode}`);
    }
    return tuning;
  }

  return {
    policy,
    levels,
    levelToRank,
    rankToLevel,
    clampRoleRank,
    scoreBandRank,
    dutyFloorRank,
    modeTuning,
  };
}

function resolveWorkerReasoning(bin, mode, reasoningContext) {
  const tuning = reasoningContext.modeTuning(mode);
  const scoreRank = reasoningContext.scoreBandRank(bin.score);
  let rank = Math.max(scoreRank, bin.minRank);
  rank += tuning.workerOffset;

  const gate = tuning.workerDownshiftGates.find((item) => bin.score <= item.maxScore);
  if (gate) {
    rank += gate.offset;
  }

  rank = Math.max(rank, bin.minRank);
  rank = reasoningContext.clampRoleRank(rank, "worker");
  return reasoningContext.rankToLevel(rank);
}

function resolveSubOrchestratorReasoning(sub, workersById, mode, reasoningContext) {
  const tuning = reasoningContext.modeTuning(mode);
  const escalation = reasoningContext.policy.escalation;
  const thresholdRank = reasoningContext.levelToRank(escalation.subHighWorkerThreshold);

  const highWorkerCount = sub.managedWorkers.filter((id) => {
    const worker = workersById.get(id);
    return worker && reasoningContext.levelToRank(worker.reasoning) >= thresholdRank;
  }).length;

  const subMinRank = reasoningContext.levelToRank(reasoningContext.policy.roleBounds.subOrchestrator.min);
  let rank = subMinRank;
  rank += Math.floor(sub.totalDutyScore / escalation.subDutyScoreStep);

  if (highWorkerCount > 0) {
    rank += escalation.subHighWorkerBoost;
  }

  rank += tuning.subOffset;
  rank = reasoningContext.clampRoleRank(rank, "subOrchestrator");
  return reasoningContext.rankToLevel(rank);
}

function resolveOrchestratorReasoning(subOrchestrators, workers, mode, reasoningContext) {
  const tuning = reasoningContext.modeTuning(mode);
  const escalation = reasoningContext.policy.escalation;
  const minRank = reasoningContext.levelToRank(reasoningContext.policy.roleBounds.orchestrator.min);
  let rank = minRank;

  rank += Math.floor(subOrchestrators.length / escalation.orchestratorSubCountStep);
  rank += Math.floor(workers.length / escalation.orchestratorWorkerCountStep);

  const thresholdRank = reasoningContext.levelToRank(escalation.subHighWorkerThreshold);
  const highReasoningWorkers = workers.filter((worker) => reasoningContext.levelToRank(worker.reasoning) >= thresholdRank).length;
  const ratio = workers.length > 0 ? highReasoningWorkers / workers.length : 0;
  if (workers.length >= escalation.orchestratorHighWorkerMinCount && ratio >= escalation.orchestratorHighWorkerRatio) {
    rank += escalation.orchestratorHighWorkerBoost;
  }

  rank += tuning.orchestratorOffset;
  rank = reasoningContext.clampRoleRank(rank, "orchestrator");
  return reasoningContext.rankToLevel(rank);
}

function makeWorkerBins(workerCount, reasoningContext) {
  const workerMinRank = reasoningContext.levelToRank(reasoningContext.policy.roleBounds.worker.min);
  const bins = Array.from({ length: workerCount }, (_, idx) => ({
    idx: idx + 1,
    duties: [],
    score: 0,
    minRank: workerMinRank,
  }));

  const sortedDuties = [...DUTY_CATALOG].sort((a, b) => b.complexity - a.complexity);
  for (const duty of sortedDuties) {
    bins.sort((a, b) => {
      if (a.score !== b.score) return a.score - b.score;
      if (a.duties.length !== b.duties.length) return a.duties.length - b.duties.length;
      return a.idx - b.idx;
    });
    const target = bins[0];
    target.duties.push(duty);
    target.score += duty.complexity;
    target.minRank = Math.max(target.minRank, reasoningContext.dutyFloorRank(duty.complexity));
  }

  return bins.sort((a, b) => a.idx - b.idx);
}

function pickRoleName(duties) {
  if (duties.length === 1) return `${duties[0].short} Worker`;
  if (duties.length === 2) return `${duties[0].short} + ${duties[1].short} Worker`;
  return `${duties[0].short}-centric Worker`;
}

function makeWorkerInstruction(worker, supervisorId) {
  const duties = worker.duties.map((item) => item.name).join(", ");
  return composeMMInstruction(
    `You are ${worker.id} in the Miyu team and a top-tier Codeforces Grandmaster subagent.`,
    `You execute ${worker.role} responsibilities across ${duties}, implement and validate work items, report all progress to ${supervisorId}, complete at least two feedback round trips for each task, apply review feedback with evidence, and submit status in Decision, Evidence, Risk, Request, Next format until approval is achieved.`
  );
}

function makeSubOrchestratorInstruction(sub) {
  return composeMMInstruction(
    `You are ${sub.id} in the Miyu team and a top-tier Codeforces Grandmaster subagent.`,
    `You supervise your assigned worker group with reasoning ${sub.reasoning}, do not perform direct implementation edits, collect worker feedback, resolve conflicts and risks, compile round summaries, report aggregated outcomes to Orchestrator-X, and issue reallocation instructions based on approved direction using Decision, Evidence, Risk, Request, Next format.`
  );
}

function makeOrchestratorInstruction(subCount, modeName, orchestratorReasoning) {
  return composeMMInstruction(
    "You are Orchestrator-X in the Miyu team and a top-tier Codeforces Grandmaster.",
    `You operate with ${orchestratorReasoning} reasoning and mode ${modeName}, define direction, priorities, and approvals only, do not perform direct implementation edits, consume aggregated reports from ${subCount} sub-orchestrators, update strategy and quality gates, decide acceptance or replanning at round boundaries, and keep the team aligned on functional correctness, security, performance, and documentation completeness.`
  );
}

function assignWorkersToSubOrchestrators(workers, subOrchestratorCount) {
  const subOrchestrators = Array.from({ length: subOrchestratorCount }, (_, idx) => ({
    id: `SubOrchestrator-${String(idx + 1).padStart(2, "0")}`,
    managedWorkers: [],
    totalDutyScore: 0,
  }));

  const sortedWorkers = [...workers].sort((a, b) => b.dutyScore - a.dutyScore);
  for (const worker of sortedWorkers) {
    subOrchestrators.sort((a, b) => {
      if (a.totalDutyScore !== b.totalDutyScore) return a.totalDutyScore - b.totalDutyScore;
      return a.managedWorkers.length - b.managedWorkers.length;
    });
    const target = subOrchestrators[0];
    target.managedWorkers.push(worker.id);
    target.totalDutyScore += worker.dutyScore;
    worker.supervisorId = target.id;
  }

  return subOrchestrators.sort((a, b) => a.id.localeCompare(b.id));
}

function buildWorkerFeedbackMatrix(workers, subOrchestrators) {
  const workerBySub = new Map();
  for (const sub of subOrchestrators) {
    workerBySub.set(sub.id, [...sub.managedWorkers]);
  }

  const allWorkerIds = workers.map((item) => item.id);
  const matrix = [];

  for (const worker of workers) {
    const group = workerBySub.get(worker.supervisorId) || [];
    let round1Reviewer;

    if (group.length > 1) {
      const idx = group.indexOf(worker.id);
      round1Reviewer = group[(idx + 1) % group.length];
    } else {
      const selfIdx = allWorkerIds.indexOf(worker.id);
      round1Reviewer = allWorkerIds[(selfIdx + 1) % allWorkerIds.length];
    }

    matrix.push({
      implementer: worker.id,
      round1Reviewer,
      round2Reviewer: worker.supervisorId,
      escalationPath: [worker.supervisorId, "Orchestrator-X"],
      requiredRoundTrips: 2,
    });
  }

  return matrix;
}

function modePolicy(mode) {
  if (mode === MODES.HIGH_COST_HIGH_EFFICIENCY) {
    return {
      name: "High-Cost High-Efficiency Mode",
      summary: "Expands reasoning budget to increase review depth and reliability margin.",
      defaultForWorkspace: false,
    };
  }
  return {
    name: "Low-Cost High-Efficiency Mode",
    summary: "Minimizes reasoning cost while preserving supervision-based quality controls.",
    defaultForWorkspace: true,
  };
}

function buildPlan(totalAgents, mode, requestedSubOrchestrators, reasoningContext, reasoningPolicyMeta) {
  const subOrchestratorCount = resolveSubOrchestratorCount(totalAgents, requestedSubOrchestrators);
  const workerCount = totalAgents - 1 - subOrchestratorCount;
  if (workerCount < 1) {
    throw new Error("worker count must be at least 1");
  }

  const workerBins = makeWorkerBins(workerCount, reasoningContext);
  const workers = workerBins.map((bin) => ({
    id: `Worker-${String(bin.idx).padStart(2, "0")}`,
    role: pickRoleName(bin.duties),
    reasoning: resolveWorkerReasoning(bin, mode, reasoningContext),
    dutyScore: bin.score,
    duties: bin.duties.map((duty) => ({
      id: duty.id,
      name: duty.name,
      complexity: duty.complexity,
    })),
    supervisorId: "",
  }));

  const subOrchestrators = assignWorkersToSubOrchestrators(workers, subOrchestratorCount);
  const workersById = new Map(workers.map((item) => [item.id, item]));
  for (const sub of subOrchestrators) {
    sub.reasoning = resolveSubOrchestratorReasoning(sub, workersById, mode, reasoningContext);
    sub.directEditing = false;
    sub.instructionMM = makeSubOrchestratorInstruction(sub);
  }

  for (const worker of workers) {
    worker.instructionMM = makeWorkerInstruction(worker, worker.supervisorId);
  }

  const orchestratorReasoning = resolveOrchestratorReasoning(subOrchestrators, workers, mode, reasoningContext);
  const policy = modePolicy(mode);
  const workerFeedback = buildWorkerFeedbackMatrix(workers, subOrchestrators);
  const subReports = subOrchestrators.map((sub) => ({
    subOrchestrator: sub.id,
    receivesFromWorkers: [...sub.managedWorkers],
    reportsTo: "Orchestrator-X",
    reportFields: ["Decision", "Evidence", "Risk", "Request", "Next"],
  }));

  return {
    version: "3.1.0",
    generatedAt: new Date().toISOString(),
    requestedTotalAgents: totalAgents,
    mode,
    modeProfile: policy,
    personaProfile: {
      key: "ray-codeforces-grandmaster-mm",
      appliesTo: "all agents",
      summary: "All generated agents inherit the Ray MM baseline and Codeforces Grandmaster identity.",
    },
    reasoningPolicy: {
      source: reasoningPolicyMeta.source,
      levels: reasoningContext.policy.levels,
      roleBounds: reasoningContext.policy.roleBounds,
      dutyComplexityFloor: reasoningContext.policy.dutyComplexityFloor,
      workerScoreBands: reasoningContext.policy.workerScoreBands,
      modeTuning: reasoningContext.policy.modeTuning,
      escalation: reasoningContext.policy.escalation,
    },
    hierarchy: {
      directEditingPolicy: {
        orchestratorDirectEdit: false,
        subOrchestratorDirectEdit: false,
        workerDirectEdit: true,
      },
      counts: {
        orchestrator: 1,
        subOrchestrators: subOrchestratorCount,
        workers: workerCount,
      },
    },
    orchestrator: {
      id: "Orchestrator-X",
      reasoning: orchestratorReasoning,
      directEditing: false,
      instructionMM: makeOrchestratorInstruction(subOrchestratorCount, policy.name, orchestratorReasoning),
    },
    subOrchestrators,
    workers,
    feedbackProtocol: {
      minimumRoundTripsPerTask: 2,
      requiredFields: ["Decision", "Evidence", "Risk", "Request", "Next"],
      workerFeedbackMatrix: workerFeedback,
      subOrchestratorReportFlow: subReports,
    },
    executionPhases: [
      "Phase 0: Orchestrator-X defines direction and scope",
      "Phase 1: Sub-orchestrators decompose and assign",
      "Phase 2: Workers implement and complete feedback loops",
      "Phase 3: Sub-orchestrators aggregate and escalate",
      "Phase 4: Orchestrator-X decides closure or replanning",
    ],
  };
}

function renderMarkdown(plan) {
  const lines = [];
  lines.push("# Agent Instructions (MM, Hierarchical)");
  lines.push("");
  lines.push(`- GeneratedAt: ${plan.generatedAt}`);
  lines.push(`- TotalAgents: ${plan.requestedTotalAgents}`);
  lines.push(`- Mode: ${plan.modeProfile.name} (${plan.mode})`);
  lines.push(`- SubOrchestrators: ${plan.hierarchy.counts.subOrchestrators}`);
  lines.push(`- Workers: ${plan.hierarchy.counts.workers}`);
  lines.push(`- PersonaProfile: ${plan.personaProfile.key}`);
  lines.push(`- ReasoningPolicySource: ${plan.reasoningPolicy.source}`);
  lines.push("");

  lines.push("## Direct Editing Policy");
  lines.push("");
  lines.push(`- Orchestrator-X direct edit: ${plan.hierarchy.directEditingPolicy.orchestratorDirectEdit}`);
  lines.push(`- Sub-orchestrator direct edit: ${plan.hierarchy.directEditingPolicy.subOrchestratorDirectEdit}`);
  lines.push(`- Worker direct edit: ${plan.hierarchy.directEditingPolicy.workerDirectEdit}`);
  lines.push("");

  lines.push("## Orchestrator-X");
  lines.push("");
  lines.push("```text");
  lines.push(plan.orchestrator.instructionMM);
  lines.push("```");
  lines.push("");

  lines.push("## Sub-Orchestrators");
  lines.push("");
  for (const sub of plan.subOrchestrators) {
    lines.push(`### ${sub.id} | ${sub.reasoning}`);
    lines.push("- Managed workers:");
    for (const workerId of sub.managedWorkers) {
      lines.push(`  - ${workerId}`);
    }
    lines.push("```text");
    lines.push(sub.instructionMM);
    lines.push("```");
    lines.push("");
  }

  lines.push("## Workers");
  lines.push("");
  for (const worker of plan.workers) {
    lines.push(`### ${worker.id} | ${worker.role} | ${worker.reasoning} | supervisor ${worker.supervisorId}`);
    lines.push("- Duties:");
    for (const duty of worker.duties) {
      lines.push(`  - ${duty.name} (complexity ${duty.complexity})`);
    }
    lines.push("```text");
    lines.push(worker.instructionMM);
    lines.push("```");
    lines.push("");
  }

  lines.push("## Worker Feedback Matrix");
  lines.push("");
  for (const row of plan.feedbackProtocol.workerFeedbackMatrix) {
    lines.push(
      `- ${row.implementer} -> Round1 ${row.round1Reviewer} -> Round2 ${row.round2Reviewer} -> Escalate ${row.escalationPath.join(
        " -> "
      )}`
    );
  }
  lines.push("");

  lines.push("## Sub-Orchestrator Report Flow");
  lines.push("");
  for (const row of plan.feedbackProtocol.subOrchestratorReportFlow) {
    lines.push(`- ${row.subOrchestrator} receives ${row.receivesFromWorkers.join(", ")} and reports to ${row.reportsTo}`);
  }
  lines.push("");
  return lines.join("\n");
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const reasoningPolicyMeta = loadReasoningPolicy(args);
  const reasoningContext = createReasoningContext(reasoningPolicyMeta.policy);
  const plan = buildPlan(args.agents, args.mode, args.subOrchestrators, reasoningContext, reasoningPolicyMeta);
  ensureDir(args.outputDir);

  const jsonPath = path.join(args.outputDir, "team-plan.json");
  const mdPath = path.join(args.outputDir, "agent-instructions.mm.md");

  fs.writeFileSync(jsonPath, `${JSON.stringify(plan, null, 2)}\n`, "utf8");
  fs.writeFileSync(mdPath, `${renderMarkdown(plan)}\n`, "utf8");

  process.stdout.write(`Generated: ${jsonPath}\n`);
  process.stdout.write(`Generated: ${mdPath}\n`);
  process.stdout.write(`Mode: ${plan.modeProfile.name}\n`);
  process.stdout.write(`Reasoning policy: ${plan.reasoningPolicy.source}\n`);
  process.stdout.write(`Orchestrator reasoning: ${plan.orchestrator.reasoning}\n`);
  process.stdout.write(`Sub-orchestrators: ${plan.hierarchy.counts.subOrchestrators}\n`);
  process.stdout.write(`Workers: ${plan.hierarchy.counts.workers}\n`);
}

try {
  main();
} catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exit(1);
}
