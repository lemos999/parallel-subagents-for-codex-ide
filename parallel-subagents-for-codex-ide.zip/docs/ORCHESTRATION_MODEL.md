# Orchestration Model

## Objective

Automatically compose a hierarchical team for Codex IDE from user-defined headcount and mode, while enforcing a supervision-first workflow.

## Inputs

- `--agents N`
  - total headcount, minimum 3, maximum 40
- `--mode M`
  - `low` (`low-cost-high-efficiency`)
  - `high` (`high-cost-high-efficiency`)
- `--sub-orchestrators S`
  - `auto` or integer
  - integer range: 1 to `N - 2`
- `--reasoning-policy-json J`
  - inline JSON override for reasoning variables
- `--reasoning-policy-file P`
  - JSON file override for reasoning variables
- `CODEX_REASONING_POLICY_JSON`
  - environment-level JSON override

## Fixed Constraints

1. `Orchestrator-X` is always present as a single top-level orchestrator.
2. `Orchestrator-X` does not directly edit implementation code.
3. sub-orchestrators supervise workers and aggregate reports.
4. sub-orchestrators do not directly edit implementation code.
5. workers are the only direct implementation editors.
6. every implementation task must complete at least 2 feedback round trips.
7. every reporting round uses `Decision`, `Evidence`, `Risk`, `Request`, `Next`.
8. default mode is `low`.
9. all generated agents inherit the global MM persona baseline (`Ray` + top-tier Codeforces Grandmaster identity).

## Composition Algorithm

1. reserve one slot for `Orchestrator-X`
2. resolve sub-orchestrator count:
  - `auto` uses `round((N - 1) / 4)` clamped to valid bounds
3. resolve reasoning policy variables with precedence:
  - base policy
  - `CODEX_REASONING_POLICY_JSON`
  - `--reasoning-policy-json`
  - `--reasoning-policy-file`
4. validate resolved policy schema
5. assign remaining slots to workers
6. distribute workload catalog (16 duties) across workers using score balancing
7. compute worker reasoning from:
  - workload score bands
  - duty complexity floors
  - mode offsets and downshift gates
8. assign workers to sub-orchestrators using balanced duty score
9. compute sub-orchestrator reasoning from:
  - managed workload
  - high-reasoning worker ratio
  - mode offsets
10. compute orchestrator reasoning from:
  - sub-orchestrator count
  - worker count
  - high-reasoning worker ratio
  - mode offsets

## Reasoning Policy Variables

- `levels`
  - ordered reasoning ladder used as rank source
- `roleBounds`
  - min/max reasoning range per role (`orchestrator`, `subOrchestrator`, `worker`)
- `dutyComplexityFloor`
  - minimum reasoning floor by duty complexity
- `workerScoreBands`
  - score-to-reasoning mapping for worker baseline
- `modeTuning`
  - mode-specific offsets and worker downshift gates
- `escalation`
  - supervision escalation thresholds for sub-orchestrator and orchestrator reasoning

## Feedback Loop

1. Round 1
- worker implementer -> worker peer reviewer
2. Round 2
- worker implementer -> assigned sub-orchestrator reviewer
3. Round Closing
- sub-orchestrator aggregates managed worker outcomes
- sub-orchestrator reports aggregate to `Orchestrator-X`
- `Orchestrator-X` decides direction changes and reallocation only

## Generated Outputs

- `generated/team-plan.json`
  - hierarchy
  - role assignments
  - persona profile
  - reasoning assignments
  - reasoning policy snapshot
  - feedback matrix
- `generated/agent-instructions.mm.md`
  - MM-style custom instructions for all role layers
