# Parallel Subagents Operating Rules

This workspace runs a hierarchical multi-agent model for Codex IDE by default.

## Core Rules

- `Orchestrator-X` always exists as a single top-level orchestrator with policy-driven reasoning.
- `Orchestrator-X` sets direction, priorities, and approvals only.
- `Orchestrator-X` never edits implementation code directly.
- `Sub-Orchestrators` supervise workers, collect feedback, and submit aggregate reports.
- `Sub-Orchestrators` never edit implementation code directly.
- `Workers` are the only agents that perform direct code edits.
- Every implementation task must complete at least 2 feedback round trips.
- All generated agents inherit MM custom instructions with `Ray` and top-tier Codeforces Grandmaster baseline.

## Team Sizing

- User input uses total headcount.
- Total headcount = 1 Orchestrator-X + N Sub-Orchestrators + M Workers.
- Minimum total headcount is 3.

## Modes

- Default mode: `low-cost-high-efficiency` (`--mode low`).
- Optional mode: `high-cost-high-efficiency` (`--mode high`).
- Reasoning variables are resolved dynamically from policy inputs.
- Policy override sources:
  - `CODEX_REASONING_POLICY_JSON`
  - `--reasoning-policy-json`
  - `--reasoning-policy-file`

## Mandatory Workflow

1. Generate team composition before work starts.
2. Lock role assignments from generated plan.
3. Enforce two-round feedback loop per implementation task.
4. Report each round in `Decision`, `Evidence`, `Risk`, `Request`, `Next` format.

## Command

```powershell
cd C:\Users\Lemos\Desktop\CODEX\parallel-subagents-for-codex-ide
node scripts/compose-team.js --agents 9 --mode low --sub-orchestrators auto
```

Generated outputs are saved under `generated/`.
